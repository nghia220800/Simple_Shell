#include "SimpleShell.h"
int main(){
    shell_loop();
    return EXIT_SUCCESS;
}